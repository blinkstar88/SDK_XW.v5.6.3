#!/bin/sh
echo -e "Content-Type: text/plain;\r\n"
cat /etc/board.info

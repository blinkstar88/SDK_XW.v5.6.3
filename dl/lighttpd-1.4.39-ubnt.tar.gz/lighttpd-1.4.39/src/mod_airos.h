#ifndef _MOD_AIROS_H_
#define _MOD_AIROS_H_
/**
 * This file is a part of mod_airos plugin.
 * Copyright (c) 2009 Ubiquiti Networks, Inc.
 */

#define SESSION_TYPE 0x00
#define TICKET_TYPE 0x0a

#define SESSION_V1 0x01
#define TICKET_V1 0x01

#define SESSION_VERSION (SESSION_TYPE << 8 | SESSION_V1)
#define TICKET_VERSION (TICKET_TYPE << 8 | TICKET_V1)

#define VERSION_MASK 0xff
#define TYPE_MASK 0xff00

#define MA_T(a) (*((unsigned short*)(a)))
#define MA_VERSION(a) (MA_T(a) & VERSION_MASK)
#define MA_TYPE(a) ((MA_T(a) & TYPE_MASK) >> 8)

#define IS_SESSION(a) (MA_TYPE(a) == SESSION_TYPE)
#define IS_TICKET(a)  (MA_TYPE(a) == TICKET_TYPE)

typedef struct session {
	unsigned short type; /* structure type/version */
	char session_id[33]; /* 32 + '\0' */
	char ipaddr[50]; /* enough to hold IPv6 */
	time_t time_created;
	time_t time_lastaccess;
	char authenticated; /* 0 - not authenticated */
	char level; /* authorization level to separate guests from admins, etc */
	char username[16]; /* makes sense only when authenticated */
	uid_t uid;         /* user id - filled in during authentication */
	gid_t gid;         /* group id - filled in during authentication */
} session_t;

typedef struct ticket {
	unsigned short type; /* structure type/version */
	char ticket_id[33]; /* 32 + '\0' */
	time_t time_created;
	char username[16];
} ticket_t;


#endif /* _MOD_AIROS_H_ */
